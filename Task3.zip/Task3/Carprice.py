import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
from sklearn.linear_model import LinearRegression
warnings.filterwarnings("ignore")
file_path = r"C:\Users\geeth\522\CarPrice.csv"
data = pd.read_csv(file_path)
numeric_data = data.select_dtypes(include=[np.number])#selects numeric datatypes
print(numeric_data.head())
print()
print(numeric_data.isnull().sum())
print()
print(numeric_data.info())
print()
print(numeric_data.describe())
print()
print(numeric_data.corr())
print()
plt.figure(figsize=(20, 15))
correlations = numeric_data.corr()
sns.heatmap(correlations, cmap="coolwarm", annot=True)
plt.show()
numeric_data.replace([np.inf, -np.inf], np.nan, inplace=True)
sns.set_style("whitegrid")
plt.figure(figsize=(15, 10))
sns.histplot(numeric_data["price"])
plt.show()
predict = "price"
numeric_data = numeric_data[[ "symboling", "wheelbase", "carlength","carwidth", "carheight", "curbweight","enginesize", "boreratio", "stroke",
    "compressionratio", "horsepower", "peakrpm","citympg", "highwaympg", "price"
]]
x = np.array(numeric_data.drop([predict], axis=1))
y = np.array(numeric_data[predict])
xtrain, xtest, ytrain, ytest = train_test_split(x, y, test_size=0.2)
model = LinearRegression()
model.fit(xtrain, ytrain)
predictions = model.predict(xtest)
mae = mean_absolute_error(ytest, predictions)
print("Mean Absolute Error:", mae)
print("Prediction: {}".format(predictions))